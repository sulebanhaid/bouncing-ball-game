# Interactive Bouncing Ball Physics Simulation

## Overview

This project is an interactive physics simulation written in C using raylib.

The user can add and remove balls, pause and reset the simulation, and adjust gravity and bounce energy. Balls collide with the window edges and with each other.

## Controls

- Left-click: add a ball
- Right-click: remove a ball
- Space: pause or resume
- C: clear all balls
- R: reset the simulation
- Up/Down arrows: change gravity
- Left/Right arrows: change bounce energy

## Project Structure

- `main.c`: input, game loop and interface
- `ball.c`: movement, drawing and collisions
- `ball.h`: Ball struct and function declarations

## Compilation

```bash
gcc main.c ball.c -o game -lraylib -lopengl32 -lgdi32 -lwinmm